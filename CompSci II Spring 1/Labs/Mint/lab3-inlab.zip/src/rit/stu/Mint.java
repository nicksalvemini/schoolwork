package rit.stu;

/**
 * Module responsible for implementing the Mint language
 * and building the proper parse tree
 *
 * @author Nick Salvemini
 */
public class Mint {
    
    public static void main(String[] args) {
    }
}
