package toys;

/**
 * A concrete Robot that can be made
 * and played with
 *
 * @author Nick Salvemini
 */
public class Robot extends BatteryPowered{

    protected Robot(String name, int numBatteries, boolean flying){
        super(0, name, numBatteries);
    }
    public boolean isFlying(){
        return false;
    }
    public int getDistance(){
        return 0;
    }
    protected void specialPlay(int time){}
}
