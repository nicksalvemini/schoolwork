package toys;

/**
 * A concrete RC Car that can be made
 * and played with
 *
 * @author Nick Salvemini
 */
public class RCCar extends BatteryPowered{

    protected RCCar(String name, int numBatteries){
        super(0, name, numBatteries);

    }

    public int getSpeed(){
        return 0;
    }
    protected void specialPlay(int time){}
    public String toString(){
        return null;
    }
}
