package toys;

/**
 * The abstract superclass for all battery
 * powered toys
 *
 * @author Nick Salvemini
 */
public abstract class BatteryPowered extends Toy{

    public final static int FULLY_CHARGED = 100;
    public final static int DEPLETED = 0;

    public BatteryPowered(int productCode, String name, int numBatteries){
        super(productCode, name);
    }

    public int getBatteryLevel(){
        return 0;
    }
    public int getNumBatteries(){
        return 0;
    }
    public void useBatteries(int time){

    }
    public String toString(){
        return null;
    }
}
