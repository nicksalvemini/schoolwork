package toys;

/**
 * A concrete doll that can be made
 * and played with
 *
 * @author Nick Salvemini
 */
public class Doll extends Toy{

    /** The name of the doll */
    private final String name;

    /** The hair color of the doll */
    private final Color hairColor;

    /** The age of the doll */
    private int age;

    /** The doll's catchphrase */
    private final String speak;

    /** The product code of the doll */
    private static int productCode = 200;

    /**
     * Constructor for the doll toy
     *
     * @param name Name of the doll
     * @param hairColor Hair color of the doll
     * @param age Age of the doll
     * @param speak Catchphrase of the doll
     */
    protected Doll(String name, Color hairColor, int age, String speak){
        super(productCode, name);
        productCode++;
        this.name = name;
        this.hairColor = hairColor;
        this.age = age;
        this.speak = speak;
    }

    public Color getHairColor(){
        return null;
    }
    public int getAge(){
        return 0;
    }
    public String getSpeak(){
        return null;
    }

    /**
     * Displays a play message for the doll
     * and then increases its wear
     *
     * @param time Amount of minutes to play with the doll
     */
    @Override
    protected void specialPlay(int time){
        System.out.println("\tArts and crafting with " +
                 " " + getName());
        increaseWear(time);
    }

    /**
     * Override of the toString()
     *
     * @return Returns a nicely formatted list
     *          of information about the doll
     */
    @Override
    public String toString(){
        return super.toString() + ", PlayDough{C:"
                +  "}";
    }

}