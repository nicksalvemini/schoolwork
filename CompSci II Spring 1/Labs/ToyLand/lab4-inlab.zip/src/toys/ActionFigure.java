package toys;

/**
 * A concrete Action Figure that can be made
 * and played with
 *
 * @author Nick Salvemini
 */
public class ActionFigure extends Doll{

    public final static int MIN_ENERGY_LEVEL = 1;
    public final static Color HAIR_COLOR = Color.ORANGE;
    private int energyLevel;

    /**
     * Constructor for the Action Figure toy
     *
     * @param name Name of the Action Figure
     */
    protected ActionFigure(String name, int age, String speak){
        super(name, HAIR_COLOR, age, speak);
        energyLevel = MIN_ENERGY_LEVEL;
    }

    public int getEnergyLevel(){
        return 0;
    }

    /**
     * Displays a play message for the Action Figure
     * and then increases its wear
     *
     * @param time Amount of minutes to play with the Action Figure
     */
    @Override
    protected void specialPlay(int time){
        System.out.println("\tArts and crafting with "
                + " " + getName());
        increaseWear(time);
    }

    /**
     * Override of the toString()
     *
     * @return Returns a nicely formatted list
     *          of information about the Action Figure
     */
    @Override
    public String toString(){
        return super.toString() + ", PlayDough{C:"
                 + "}";
    }

}