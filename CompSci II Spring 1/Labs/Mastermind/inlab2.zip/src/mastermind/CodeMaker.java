package mastermind;

public class CodeMaker {
    private String secretCode;

    public CodeMaker(String code){
        secretCode = code;
    }

    public void checkGuess(Guess guess){
    }

    public String getSecretCode(){
        return null;
    }
}
