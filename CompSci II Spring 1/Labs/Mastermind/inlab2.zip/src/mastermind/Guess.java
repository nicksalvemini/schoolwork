package mastermind;

public class Guess {
    private static int currentGuessNumber = 1;
    private int guessNumber;
    private String guess;
    private int correctPositions;
    private int wrongPositions;

    public Guess(String guess) {
        this.guess = guess;
        guessNumber = currentGuessNumber;
        currentGuessNumber++;
    }

    public int getCorrectPositions() {
        return correctPositions;
    }

    public void setCorrectPositions(int correctPositions) {
        this.correctPositions = correctPositions;
    }

    public int getWrongPositions(){ return wrongPositions; }

    public void setWrongPositions(int wrongPositions){
        this.wrongPositions = wrongPositions;
    }

    public String getString(){ return guess; }

    @Override
    public String toString() {
        return "Guess #" + this.guessNumber + ": " + guess + " (B:"
                + correctPositions + " W:" + wrongPositions + ")";
    }
}
